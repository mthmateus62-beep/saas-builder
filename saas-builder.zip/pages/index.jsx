import React, { useState } from 'react';

const TEMPLATE_FILES = {
  'README.md': `# Meu SaaS Gerado\n\nEste é um app gerado automaticamente pelo Nylus-like Starter. Personalize à vontade.`,
  'package.json': `{
  "name": "meu-saas-gerado",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  }
}`,
  'pages/index.jsx': `export default function Home(){return (<div style={{padding:32}}>Olá! Este é o app gerado.</div>)}`
}

function downloadAsTxt(filename, content) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export default function Home() {
  const [name, setName] = useState('MinhaApp')
  const [purpose, setPurpose] = useState('CRM simples')
  const [theme, setTheme] = useState('neon')
  const [generating, setGenerating] = useState(false)
  const [generatedPreview, setGeneratedPreview] = useState(null)

  function handleGenerate() {
    setGenerating(true)
    setTimeout(() => {
      const readme = `# ${name}\n\nAplicação gerada: ${name} - Função: ${purpose}\nTema: ${theme}`
      const indexCode = `export default function Home(){return (<div style={{padding:24,fontFamily:\"Inter, sans-serif\"}}> <h1>${name}</h1> <p>${purpose}</p> </div>)}`
      const files = {
        'README.md': readme,
        'package.json': TEMPLATE_FILES['package.json'],
        'pages/index.jsx': indexCode
      }
      setGeneratedPreview(files)
      setGenerating(false)
    }, 900)
  }

  function handleDownloadAll() {
    if (!generatedPreview) return
    let content = ''
    Object.entries(generatedPreview).forEach(([path, txt]) => {
      content += `---FILE:${path}---\n${txt}\n\n`
    })
    downloadAsTxt(`${name.replace(/\s+/g,'_')}_nylus_bundle.txt`, content)
  }

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <nav className="max-w-5xl mx-auto p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center">N</div>
          <div className="text-lg font-bold">Nylus - Criador de SaaS</div>
        </div>
        <div className="text-sm opacity-80">Beta • Gerador de apps com IA</div>
      </nav>

      <header className="max-w-5xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl font-extrabold leading-tight">Crie seu <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-300">SaaS</span> com IA — em minutos</h1>
          <p className="mt-4 text-gray-300">Escolha template, personalize e gere um projeto Next.js pronto para deploy. Deploy automático com Vercel e repositório no GitHub.</p>

          <div className="mt-6 flex gap-3">
            <button className="px-5 py-3 rounded-md bg-gradient-to-r from-purple-600 to-indigo-600 font-semibold">Começar grátis</button>
            <button className="px-5 py-3 rounded-md border border-purple-800 text-sm">Ver planos</button>
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="p-4 rounded-md bg-neutral-900/40">
              <div className="font-bold">+ Templates</div>
              <div className="opacity-80">CRM, Blog, Dashboard</div>
            </div>
            <div className="p-4 rounded-md bg-neutral-900/40">
              <div className="font-bold">Deploy</div>
              <div className="opacity-80">Vercel + GitHub</div>
            </div>
            <div className="p-4 rounded-md bg-neutral-900/40">
              <div className="font-bold">IA</div>
              <div className="opacity-80">Personalização automática</div>
            </div>
          </div>
        </div>

        <aside className="bg-neutral-900/30 p-6 rounded-2xl">
          <h3 className="font-semibold">Gerador Rápido (MVP)</h3>
          <div className="mt-4 flex flex-col gap-3">
            <label className="text-sm opacity-80">Nome do SaaS</label>
            <input className="p-3 rounded-md bg-black/60 border border-neutral-800" value={name} onChange={e=>setName(e.target.value)} />

            <label className="text-sm opacity-80">Propósito</label>
            <input className="p-3 rounded-md bg-black/60 border border-neutral-800" value={purpose} onChange={e=>setPurpose(e.target.value)} />

            <label className="text-sm opacity-80">Tema</label>
            <select className="p-3 rounded-md bg-black/60 border border-neutral-800" value={theme} onChange={e=>setTheme(e.target.value)}>
              <option value="neon">Neon (roxo)</option>
              <option value="clean">Clean</option>
              <option value="corporate">Corporate</option>
            </select>

            <button onClick={handleGenerate} className="mt-2 p-3 rounded-md bg-gradient-to-r from-indigo-600 to-purple-600 font-semibold">{generating ? 'Gerando...' : 'Gerar meu SaaS'}</button>

            {generatedPreview && (
              <div className="mt-4 p-3 bg-black/50 rounded-md">
                <div className="text-sm opacity-80">Preview dos arquivos gerados:</div>
                <div className="mt-2 text-xs font-mono max-h-48 overflow-auto bg-black/70 p-3 rounded-md border border-neutral-800">
                  {Object.entries(generatedPreview).map(([path, txt])=> (
                    <div key={path} className="mb-3">
                      <div className="text-xs text-purple-300">{path}</div>
                      <pre className="text-[11px] mt-1 whitespace-pre-wrap">{txt.slice(0,300)}{txt.length>300? '...':''}</pre>
                    </div>
                  ))}

                  <div className="flex gap-2 mt-2">
                    <button onClick={handleDownloadAll} className="px-3 py-2 rounded-md bg-purple-700 text-sm">Baixar bundle</button>
                    <button onClick={()=>{downloadAsTxt('README_preview.txt', generatedPreview['README.md'])}} className="px-3 py-2 rounded-md border border-neutral-800 text-sm">Baixar README</button>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-4 text-xs opacity-80">
              Observação: este gerador é um MVP frontend. Para gerar apps completos automatizados, implemente um endpoint que:
              <ul className="list-disc ml-4 mt-1">
                <li>Crie repositório GitHub</li>
                <li>Personalize templates no servidor</li>
                <li>Acione deploy na Vercel</li>
                <li>Integre com Supabase para DB e Auth</li>
              </ul>
            </div>

          </div>
        </aside>
      </header>

      <main className="max-w-5xl mx-auto p-6 space-y-12">
        <section className="grid md:grid-cols-3 gap-6">
          <Card title="Templates prontos" desc="Modelos para iniciar: CRM, Blog, Notas e Dashboard" />
          <Card title="Deploy autom." desc="Crie repositório e faça deploy automático com GitHub + Vercel" />
          <Card title="Integrações" desc="Supabase, Stripe, Mercado Pago e APIs de IA" />
        </section>

        <section className="bg-neutral-900/20 p-6 rounded-2xl">
          <h3 className="text-xl font-semibold">Como funciona (técnico)</h3>
          <ol className="list-decimal ml-6 mt-3 space-y-2 text-sm opacity-80">
            <li>Usuário preenche formulário → Escolhe template</li>
            <li>Backend recebe pedido → Clona template</li>
            <li>IA (ou template engine) substitui textos, cores e configurações</li>
            <li>Cria repositório GitHub e faz push</li>
            <li>Chama Vercel para deploy e retorna URL</li>
          </ol>
        </section>

        <section className="grid md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-gradient-to-br from-neutral-900/10 to-black/20">
            <h3 className="font-semibold">Resultados</h3>
            <div className="mt-4 grid grid-cols-3 gap-3 text-center">
              <Stat num="+3.4k" label="apps gerados" />
              <Stat num="+827k" label="requests de IA" />
              <Stat num="+12" label="templates" />
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-neutral-900/20">
            <h3 className="font-semibold">Planos (exemplo)</h3>
            <div className="mt-4 space-y-3">
              <Plan name="Starter" price="R$47/m" bullets={["1 app grátis","Templates básicos","Exportar código"]} />
              <Plan name="Pro" price="R$297/m" bullets={["Apps ilimitados","Deploy automático","Suporte prioritário"]} highlight />
            </div>
          </div>
        </section>

      </main>

      <footer className="max-w-5xl mx-auto p-6 text-center text-sm opacity-70">© {new Date().getFullYear()} Nylus-like • Feito por Mateus</footer>
    </div>
  )
}

function Card({title, desc}){
  return (
    <div className="p-6 rounded-xl bg-neutral-900/30">
      <div className="font-semibold">{title}</div>
      <div className="mt-2 text-sm opacity-80">{desc}</div>
    </div>
  )
}

function Stat({num, label}){
  return (
    <div className="p-4 bg-black/40 rounded-md">
      <div className="font-bold text-lg">{num}</div>
      <div className="text-xs opacity-80">{label}</div>
    </div>
  )
}

function Plan({name, price, bullets, highlight}){
  return (
    <div className={`p-4 rounded-md ${highlight? 'bg-gradient-to-r from-purple-700 to-indigo-700 text-white':'bg-black/40'}`}>
      <div className="flex items-center justify-between">
        <div className="font-semibold">{name}</div>
        <div className="font-bold">{price}</div>
      </div>
      <ul className="mt-3 text-sm opacity-90">
        {bullets.map(b=> <li key={b}>• {b}</li>)}
      </ul>
      <button className={`mt-4 w-full py-2 rounded-md ${highlight? 'bg-black/80':'bg-purple-700'}`}>Assinar</button>
    </div>
  )
}
