Templates disponiveis: crm, blog, dashboard, marketplace, chat-ia, tickets
Coloque aqui os arquivos de cada template em subpastas para enviar ao GitHub.